=== Spaceremit Gateway for WooCommerce ===
Contributors: spaceremit
Tags: woocommerce, payment, gateway, spaceremit, credit card, local payment
Requires at least: 5.0
Tested up to: 6.4
Requires PHP: 7.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

بوابة دفع Spaceremit لـ WooCommerce - تدعم الدفع بالبطاقات الائتمانية والطرق المحلية

== Description ==

إضافة WordPress تسمح لموقع WooCommerce بقبول المدفوعات عبر بوابة دفع Spaceremit.

**المميزات:**
* دعم الدفع بالبطاقات الائتمانية (Visa, Mastercard)
* دعم طرق الدفع المحلية
* وضع الاختبار والإنتاج
* معالجة تلقائية للـ Callbacks
* تحديث حالة الطلبات تلقائياً
* واجهة سهلة الاستخدام

== Installation ==

1. قم بتحميل الإضافة وتفعيلها من خلال قائمة 'إضافات' في WordPress
2. تأكد من تفعيل WooCommerce
3. اذهب إلى WooCommerce > الإعدادات > الدفع
4. قم بتفعيل بوابة Spaceremit
5. أدخل مفاتيح API الخاصة بك من حساب Spaceremit
6. قم بحفظ الإعدادات

== Frequently Asked Questions ==

= كيف أحصل على مفاتيح API؟ =

قم بتسجيل الدخول إلى حسابك في Spaceremit، ثم اذهب إلى "Websites And Keys" لإضافة موقع جديد والحصول على المفاتيح.

= ما هو الفرق بين Test Mode و Live Mode؟ =

في Test Mode، يمكنك تجربة الدفعات باستخدام مفاتيح الاختبار دون استخدام أموال حقيقية. في Live Mode، ستتم معالجة المدفوعات الحقيقية.

= كيف أتأكد من أن Callbacks تعمل؟ =

تأكد من أن Callback URL في إعدادات Spaceremit يشير إلى:
`https://yourdomain.com/wp-json/spaceremit/v1/callback`

== Changelog ==

= 1.0.0 =
* الإصدار الأول
* دعم الدفع بالبطاقات الائتمانية
* دعم طرق الدفع المحلية
* معالجة Callbacks
* التحقق من الدفعات
* تحديث حالة الطلبات تلقائياً

== Upgrade Notice ==

= 1.0.0 =
الإصدار الأول من الإضافة

